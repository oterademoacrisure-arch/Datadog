# <APP-NAME>-DEPLOYMENT


### for more details please refer [PaaS EKS Ops playbook](https://confluence.corp.internal.citizensbank.com/spaces/CP/pages/593925125/PaaS+EKS+-+How+Tos) for EKS deployments.
