# DEPLOYMENT-CONFIG
# PLEASE UPDATE THE FOLLOWING FILES
#	/values/
#	Chart.yaml
# 	global.yaml
#	p2-dev-values.yaml
# 	p1-qa-values.yaml
#	p-prod-values.yaml


### for more details please refer [PaaS OCP Ops playbook](https://confluence.corp.internal.citizensbank.com/display/CP/PaaS+OPS+-+Playbook) for OpenShift deployments.

### for more details please refer [PaaS EKS Ops playbook](https://confluence.corp.internal.citizensbank.com/spaces/CP/pages/593925125/PaaS+EKS+-+How+Tos) for EKS deployments.
