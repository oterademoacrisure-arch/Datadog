# <APP-NAME>-DEPLOYMENT-OPS-UTIL


### for more details please refer [PaaS Ops playbook](https://confluence.corp.internal.citizensbank.com/display/CP/PaaS+OPS+-+Playbook)